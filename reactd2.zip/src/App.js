import logo from './logo.svg';
import './App.css';
import Loginpage from './components/Loginpage';
import Loginpages from './components/Loginpages';
import Registration from './components/Registration';
import { AppBar } from '@mui/material';
import Appbar from './components/Appbar';
import Statebasics from './components/Statebasics';
import Counter from './components/Counter';
import UseE from './components/UseE';
import Mapping from './components/Mapping';

function App() {
  return (
    <div className="App">
      {/* <Loginpages/>
      <Registration/> */}
    {/* <Appbar/>
    <Statebasics/> */}
    <Appbar/>
    {/* <Counter/>
    
   */}
   {/* <UseE/> */}
   <Mapping/>
    </div>
  );
}

export default App;
