import { Button, Typography } from '@mui/material'
import React, { useState } from 'react'

const Statebasics = () => {
    // var fname = 'Noora'
    var [fname,setFname] =useState("Noora")
    const changename = ()=>{
        console.log("clicked")
        setFname("home")
    }
  return (

    <div style={{paddingTop:"80px"}}>
    <Typography variant="h4">Welcome {fname}</Typography>
    <Button variant = "contained" onClick={changename}>change</Button>
    </div>
  )
}

export default Statebasics