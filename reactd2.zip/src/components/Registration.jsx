import { TextField, Typography } from '@mui/material'
import React from 'react'

const Registration = () => {
  return (
    <div> Registration form <br></br><br></br>
    <input type='text' placeholder='username'/><br/><br/>
    <input type='email' placeholder='email'/><br/><br/>
    <input type='password' placeholder='password'></input>
    <br></br><br></br>
    
     <button>submit</button>


        
    </div>
  )
}

export default Registration