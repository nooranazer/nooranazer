import { Button, Typography } from '@mui/material'
import React, { useEffect, useState } from 'react'

const UseE = () => {
  var [name,setName] = useState()

  const changeHname = ()=>{
    setName("home")
  }

  const changeGname = ()=>{
    setName("gallery")
  }

  const changeCname = () =>{
    setName("contact")
  }
  useEffect(()=>{
    changeGname()
  },[])   


  return (
    <div
     style={{paddingTop:"80px"}}>
        <Button variant="contained" color='primary'>home</Button>
        <Button variant="contained" color='secondary'>gallery</Button>
        <Button variant="contained" color='error'>contact</Button>
        <Typography> welcome to {home} </Typography>


        
        </div>
  )
}

export default UseE
