import { Button } from '@mui/base'
import { Typography } from '@mui/material'
import React, { useState } from 'react'

const Counter = () => {
    var[count,setcount] =useState(0)

    const incBtn = ()=>{
        console.log("Dec clicked")
        setcount(count+1)
    }
    const decBtn = ()=>{
        console.log("Dec clicked")
        setcount(count-1)
    }


  return ( 
    <div style={{paddingTop:"80px"}}>
        <Typography>counter value : {count} </Typography>
        <Button variant='contained' color='success' onClick={incBtn}>+</Button>
        <Button variant='contained' color='error' onClick={decBtn}>-</Button>


    </div>
  )
}

export default Counter