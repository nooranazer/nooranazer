import React from 'react'

const Loginpage = () => {
  return (
    <div>Loginpage
        <Loginpage/>
    </div>
    
  )
}

export default Loginpage