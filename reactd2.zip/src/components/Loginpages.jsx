import { TextField, Typography } from '@mui/material'
import React from 'react'

const Loginpages = () => {
  return (
    <div>login page<br/><br/>
        <input type="text" placeholder='username'/><br/><br/>
        <input type='password'placeholder='password'/> <br/><br/>
        <button>login</button>
        <br/><br/><br/><br/><br></br>
        <Typography variant='h4'>Login page</Typography>
        <TextField variant='outlined' label='username'/>
    </div>
  )
}

export default Loginpages