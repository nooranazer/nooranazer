import { AppBar, Button, Toolbar, Typography } from '@mui/material'
import React from 'react'

const Appbar = () => {
  return (
    <div>
        <AppBar>
            <Toolbar>
                <Typography>first app</Typography> &nbsp;
                <Button variant="contained" color="error">login</Button> &nbsp;
                <Button variant="contained" color="success">sign up</Button> &nbsp;
           </Toolbar>
        </AppBar>
    </div>
  )
}

export default Appbar