import { AppBar, Button, Toolbar, Typography } from '@mui/material'
import React from 'react'
import { Link } from 'react-router-dom'

const Appbar = () => {
  return (
    <div>
        <AppBar>
            <Toolbar>
                <Typography>first App</Typography>
                <Button variant='contained' color='success'><Link style={{textDecoration:'none'}}>view data</Link></Button> &nbsp;
                <Button variant='contained' color='error'><Link stytle={{textDecoration:'none'}}>adddata</Link></Button>
            </Toolbar>
        </AppBar>
    </div>
  )
}

export default Appbar