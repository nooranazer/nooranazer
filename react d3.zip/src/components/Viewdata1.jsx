import React from 'react'

const Viewdata1 = () => {
  return (
    <div>Viewdata1</div>
  )
}

export default Viewdata1