import { Typography } from '@mui/material'
import React from 'react'

const AddData = () => {
  return (
    <div style={{paddingTop:"80px"}}>
        <Typography>Add data</Typography>
        </div>
  )
}

export default AddData